# Medic Mobile Release Notes

Release notes are now published in the [release-notes](https://github.com/medic/cht-core/tree/master/release-notes) directory.
